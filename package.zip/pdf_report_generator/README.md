# Ride Comfort Analysis Report Generator

A simple, maintainable system for generating PDF reports from test data and plots. Designed for easy editing without requiring AI assistance.

## Quick Start

### 1. Install Dependencies

```bash
# Ubuntu/Debian
sudo apt-get install pandoc texlive-latex-base

# Python packages
pip install weasyprint
```

### 2. Add Your Plots

Place your PNG plots in the `plots/` folder:

```
plots/
├── firm_feel_acceleration.png
├── firm_feel_frequency.png
├── busy_feel_acceleration.png
├── busy_feel_frequency.png
├── time_series_full.png
└── acceleration_3d.png
```

### 3. Run the Generator

```bash
python generate_report.py
```

## How It Works

The system uses **Markdown as an intermediate format**, which means:

- You can edit the report template in any text editor
- Git tracks changes clearly (it's just text)
- No special tools needed to modify the layout
- The Python script converts Markdown to PDF

## File Structure

```
pdf_report_generator/
├── generate_report.py      # Main script - converts everything to PDF
├── report_template.md      # EDIT THIS: Your report layout
├── test_cases/            # EDIT THESE: JSON files with test data
│   ├── firm_feel.json
│   └── busy_feel.json
├── plots/                 # ADD YOUR PNG FILES HERE
│   └── (your .png files)
└── output/               # Generated files appear here
    └── report.pdf
```

## Editing the Report

### Adding Text

Just edit `report_template.md` directly. It's plain text.

**Example:**

```markdown
# My New Section

This is a paragraph. You can write anything here.

## Subsection

More content here.
```

### Adding Images

Place your PNG in the `plots/` folder, then reference it:

```markdown
![Caption for image](plots/my_image.png)
```

### Adding Variables from JSON

Reference test case data anywhere:

```markdown
The damping coefficient is: {{firm_feel.damping_coefficient}}
```

### Adding Complete Test Blocks

Insert an entire test case definition:

```markdown
{{test_case_block:firm_feel}}
```

### Using Built-in Variables

```markdown
Date: {{REPORT_DATE}}
Time: {{REPORT_TIME}}
```

## Editing Test Data

Open `test_cases/firm_feel.json` and modify:

```json
{
    "name": "Your Test Name",
    "description": "What this test measures",
    "settings": {
        "parameter1": "value1",
        "parameter2": "value2"
    }
}
```

## Report Template Format

The template uses double curly braces for placeholders:

| Format | Example | Result |
|--------|---------|--------|
| Variable | `{{VARIABLE_NAME}}` | Replaced with variable value |
| Test field | `{{test_name.field}}` | Accesses JSON field |
| Image | `![caption](plots/file.png)` | Markdown image syntax |
| Test block | `{{test_case_block:name}}` | Full formatted test case |

## Troubleshooting

### Pandoc not found

Install pandoc:

```bash
# Ubuntu/Debian
sudo apt-get install pandoc texlive-latex-base

# macOS
brew install pandoc

# Windows
# Download from https://pandoc.org/installing.html
```

### PDF looks wrong

1. Check that plots exist in `plots/` folder
2. Verify image filenames match exactly (case-sensitive)
3. Open `output/report_processed.md` to see the generated Markdown

### JSON not loading

Make sure JSON files are valid:

```bash
python -c "import json; json.load(open('test_cases/firm_feel.json'))"
```

## Customization

### Change Output Location

Edit `CONFIG` in `generate_report.py`:

```python
CONFIG = {
    "output_pdf": "my_folder/my_report.pdf",
    # ...
}
```

### Add New Variables

Add to the `simple_vars` dictionary in `generate_report.py`:

```python
simple_vars = {
    "REPORT_DATE": datetime.now().strftime("%Y-%m-%d"),
    "VEHICLE_MODEL": "Model XYZ",  # Add this
}
```

### Change PDF Styling

Modify the pandoc command in `markdown_to_pdf()` function for different styling options.

## Git Workflow

Since everything is text-based:

```bash
git add .
git commit -m "Added new test case"
git push
```

You'll see clear diffs for every change.

## License

Free to use and modify.
