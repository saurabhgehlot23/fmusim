#!/usr/bin/env python3
"""
PDF Report Generator for Ride Comfort Analysis

This script generates PDF reports from Markdown templates and JSON test data.
It uses Markdown as an intermediate format for easy editing and Git version control.

USAGE:
    python generate_report.py

STRUCTURE:
    - test_cases/*.json    : Test case definitions
    - plots/*.png          : PNG images to include
    - report_template.md   : Markdown template for the report
    - output/report.pdf    : Generated PDF report
"""

import json
import os
import subprocess
from pathlib import Path
from datetime import datetime

# ============================================================================
# CONFIGURATION - Edit these paths as needed
# ============================================================================

CONFIG = {
    "template_file": "report_template.md",
    "output_pdf": "output/report.pdf",
    "test_cases_dir": "test_cases",
    "plots_dir": "plots",
    "output_dir": "output"
}

# ============================================================================
# JSON SCHEMA - Edit these JSON files to change test case content
# ============================================================================

def load_json_schema(filepath):
    """Load and parse a JSON file."""
    with open(filepath, 'r', encoding='utf-8') as f:
        return json.load(f)

def get_all_test_cases(test_dir):
    """Load all JSON test case files from the test_cases directory."""
    test_cases = {}
    test_path = Path(test_dir)
    
    if not test_path.exists():
        print(f"Warning: {test_dir} directory not found. Creating it.")
        test_path.mkdir(parents=True, exist_ok=True)
        return test_cases
    
    for json_file in sorted(test_path.glob("*.json")):
        test_name = json_file.stem  # filename without extension
        test_cases[test_name] = load_json_schema(json_file)
        print(f"  Loaded: {json_file.name}")
    
    return test_cases

# ============================================================================
# MARKDOWN PROCESSING
# ============================================================================

def process_template(template_path, test_cases, plots_dir):
    """
    Process the Markdown template by replacing placeholders with actual data.
    
    Placeholder format:
        {{VARIABLE_NAME}}           - Simple variable replacement
        {{test_case_name.FIELD}}    - Access test case field
        {{image:PLOT_NAME}}         - Insert image from plots directory
        {{test_case_block:NAME}}    - Insert entire test case as formatted block
    """
    
    with open(template_path, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # Replace simple variables
    simple_vars = {
        "REPORT_DATE": datetime.now().strftime("%Y-%m-%d"),
        "REPORT_TIME": datetime.now().strftime("%H:%M:%S"),
    }
    
    for var_name, var_value in simple_vars.items():
        content = content.replace(f"{{{{{var_name}}}}}", str(var_value))
    
    # Replace test case fields (format: {{firm_feel.description}})
    for test_name, test_data in test_cases.items():
        if isinstance(test_data, dict):
            for field, value in test_data.items():
                placeholder = f"{{{{{test_name}.{field}}}}}"
                content = content.replace(placeholder, str(value))
    
    # Replace image placeholders (format: {{image:plot_name.png}})
    import re
    image_pattern = r'\{\{image:([^}]+)\}\}'
    
    def replace_image(match):
        image_name = match.group(1).strip()
        image_path = os.path.join(plots_dir, image_name)
        
        # Make path relative to output directory
        rel_path = os.path.relpath(image_path, CONFIG["output_dir"])
        
        # Return Markdown image syntax
        return f'\n![{image_name}]({rel_path})\n'
    
    content = re.sub(image_pattern, replace_image, content)
    
    # Replace test case blocks (format: {{test_case_block:test_name}})
    block_pattern = r'\{\{test_case_block:([^}]+)\}\}'
    
    def replace_test_block(match):
        test_name = match.group(1).strip()
        if test_name in test_cases and isinstance(test_cases[test_name], dict):
            tc = test_cases[test_name]
            lines = [
                f"### {tc.get('name', test_name)}",
                "",
                f"**Description:** {tc.get('description', 'N/A')}",
                "",
                f"**Test Settings:**",
            ]
            
            if 'settings' in tc and isinstance(tc['settings'], dict):
                for key, value in tc['settings'].items():
                    lines.append(f"- **{key}:** {value}")
            
            return '\n'.join(lines) + '\n'
        return f'\n<!-- Test case "{test_name}" not found -->\n'
    
    content = re.sub(block_pattern, replace_test_block, content)
    
    return content

# ============================================================================
# PDF CONVERSION
# ============================================================================

def markdown_to_pdf(markdown_content, output_pdf):
    """
    Convert Markdown to PDF using pandoc.
    
    Requires: pandoc and a PDF engine (pdflatex, xelatex, or weasyprint)
    Install on Ubuntu: sudo apt-get install pandoc texlive-latex-base
    """
    
    temp_md = os.path.join(CONFIG["output_dir"], "_temp_report.md")
    
    # Write processed Markdown to temp file
    with open(temp_md, 'w', encoding='utf-8') as f:
        f.write(markdown_content)
    
    # Try pandoc conversion
    try:
        # Try with pdflatex first
        cmd = [
            'pandoc',
            temp_md,
            '-o', output_pdf,
            '--pdf-engine=pdflatex',
            '-V', 'geometry:margin=1in',
            '-V', 'fontsize=11pt'
        ]
        subprocess.run(cmd, check=True, capture_output=True)
        print(f"PDF generated: {output_pdf}")
        return True
    except (subprocess.CalledProcessError, FileNotFoundError) as e:
        # Fallback: try weasyprint via HTML
        try:
            cmd = [
                'pandoc',
                temp_md,
                '-o', output_pdf.replace('.pdf', '.html'),
                '--standalone'
            ]
            subprocess.run(cmd, check=True, capture_output=True)
            
            # Convert HTML to PDF with weasyprint
            html_file = output_pdf.replace('.pdf', '.html')
            from weasyprint import HTML
            HTML(filename=html_file).write_pdf(output_pdf)
            print(f"PDF generated (via HTML): {output_pdf}")
            
            # Clean up HTML
            if os.path.exists(html_file):
                os.remove(html_file)
            return True
        except Exception as e2:
            print(f"Pandoc not found. Please install pandoc:")
            print(f"  Ubuntu/Debian: sudo apt-get install pandoc texlive-latex-base")
            print(f"  macOS: brew install pandoc")
            print(f"\nAlternatively, open {temp_md} manually and convert to PDF.")
            return False
    finally:
        # Clean up temp file
        if os.path.exists(temp_md):
            os.remove(temp_md)

# ============================================================================
# MAIN EXECUTION
# ============================================================================

def main():
    print("=" * 60)
    print("PDF Report Generator for Ride Comfort Analysis")
    print("=" * 60)
    
    # Create output directory
    os.makedirs(CONFIG["output_dir"], exist_ok=True)
    
    # Load test cases
    print("\n1. Loading test cases...")
    test_cases = get_all_test_cases(CONFIG["test_cases_dir"])
    print(f"   Found {len(test_cases)} test case(s)")
    
    # Process template
    print("\n2. Processing template...")
    processed_markdown = process_template(
        CONFIG["template_file"],
        test_cases,
        CONFIG["plots_dir"]
    )
    
    # Save processed Markdown (optional, for inspection)
    processed_md_path = os.path.join(CONFIG["output_dir"], "report_processed.md")
    with open(processed_md_path, 'w', encoding='utf-8') as f:
        f.write(processed_markdown)
    print(f"   Processed Markdown saved: {processed_md_path}")
    
    # Convert to PDF
    print("\n3. Converting to PDF...")
    success = markdown_to_pdf(processed_markdown, CONFIG["output_pdf"])
    
    if success:
        print("\n" + "=" * 60)
        print("SUCCESS! Report generated.")
        print("=" * 60)
    else:
        print("\n" + "=" * 60)
        print("PDF generation skipped. Check Markdown file.")
        print("=" * 60)

if __name__ == "__main__":
    main()
